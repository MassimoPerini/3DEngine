/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[18];
    char stringdata[295];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
offsetof(qt_meta_stringdata_MainWindow_t, stringdata) + ofs \
- idx * sizeof(QByteArrayData) \
)
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 0, 10),
        QT_MOC_LITERAL(1, 11, 22),
        QT_MOC_LITERAL(2, 34, 0),
        QT_MOC_LITERAL(3, 35, 25),
        QT_MOC_LITERAL(4, 61, 14),
        QT_MOC_LITERAL(5, 76, 14),
        QT_MOC_LITERAL(6, 91, 8),
        QT_MOC_LITERAL(7, 100, 8),
        QT_MOC_LITERAL(8, 109, 27),
        QT_MOC_LITERAL(9, 137, 27),
        QT_MOC_LITERAL(10, 165, 26),
        QT_MOC_LITERAL(11, 192, 31),
        QT_MOC_LITERAL(12, 224, 5),
        QT_MOC_LITERAL(13, 230, 16),
        QT_MOC_LITERAL(14, 247, 5),
        QT_MOC_LITERAL(15, 253, 16),
        QT_MOC_LITERAL(16, 270, 15),
        QT_MOC_LITERAL(17, 286, 7)
    },
    "MainWindow\0on_btnAddLight_clicked\0\0"
    "on_btnDeleteLight_clicked\0rowChangedSlot\0"
    "QItemSelection\0selected\0deselect\0"
    "on_btnOpenDiffColor_clicked\0"
    "on_btnOpenSpecColor_clicked\0"
    "on_btnOpenAmbColor_clicked\0"
    "on_comboBox_currentIndexChanged\0index\0"
    "diffColorChoosen\0color\0specColorChoosen\0"
    "ambColorChoosen\0"
    "confirm\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {
    
    // content:
    8,       // revision
    0,       // classname
    0,    0, // classinfo
    11,   14, // methods
    0,    0, // properties
    0,    0, // enums/sets
    0,    0, // constructors
    0,       // flags
    0,       // signalCount
    
    // slots: name, argc, parameters, tag, flags
    1,    0,   64,    2, 0x08,
    3,    0,   65,    2, 0x08,
    4,    2,   66,    2, 0x08,
    8,    0,   71,    2, 0x08,
    9,    0,   72,    2, 0x08,
    10,    0,   73,    2, 0x08,
    11,    1,   74,    2, 0x08,
    13,    1,   77,    2, 0x08,
    15,    1,   80,    2, 0x08,
    16,    1,   83,    2, 0x08,
    17,     0,  84,     2, 0x08,
    // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5, 0x80000000 | 5,    6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::QColor,   14,
    QMetaType::Void, QMetaType::QColor,   14,
    QMetaType::Void, QMetaType::QColor,   14,
    0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
            case 0: _t->on_btnAddLight_clicked(); break;
            case 1: _t->on_btnDeleteLight_clicked(); break;
            case 2: _t->rowChangedSlot((*reinterpret_cast< const QItemSelection(*)>(_a[1])),(*reinterpret_cast< const QItemSelection(*)>(_a[2]))); break;
            case 3: _t->on_btnOpenDiffColor_clicked(); break;
            case 4: _t->on_btnOpenSpecColor_clicked(); break;
            case 5: _t->on_btnOpenAmbColor_clicked(); break;
            case 6: _t->on_comboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
            case 7: _t->diffColorChoosen((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
            case 8: _t->specColorChoosen((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
            case 9: _t->ambColorChoosen((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
            case 10: _t->confirm();break;
            default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
        qt_meta_data_MainWindow,  qt_static_metacall, 0, 0}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

