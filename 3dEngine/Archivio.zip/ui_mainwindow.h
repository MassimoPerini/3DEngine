/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout_5;
    QGroupBox *Lights;
    QListView *chooseLight;
    QPushButton *btnAddLight;
    QPushButton *btnDeleteLight;
    QGroupBox *groupBox_2;
    QLineEdit *posX;
    QLineEdit *posY;
    QLineEdit *posZ;
    QLabel *labX;
    QLabel *labY;
    QLabel *labZ;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *btnOpenDiffColor;
    QPushButton *btnOpenSpecColor;
    QPushButton *btnOpenAmbColor;
  //  QLabel *label_4;
 //   QComboBox *comboBox;
    QLabel *label_5;
    QFrame *line;
    QLabel *label_8;
    QLabel *label_9;
    QDoubleSpinBox *doubleSpinBox;
    QDoubleSpinBox *doubleSpinBox_2;
    QDoubleSpinBox *doubleSpinBox_3;
    QPushButton *pushButton;
//    QPushButton *pushButton_2;
//    QProgressBar *progressBar;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    
    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(384, 571);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayoutWidget = new QWidget(centralWidget);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(10, 0, 371, 874));
        verticalLayout_5 = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        Lights = new QGroupBox(verticalLayoutWidget);
        Lights->setObjectName(QStringLiteral("Lights"));
        chooseLight = new QListView(Lights);
        chooseLight->setObjectName(QStringLiteral("chooseLight"));
        chooseLight->setGeometry(QRect(10, 40, 291, 192));
        btnAddLight = new QPushButton(Lights);
        btnAddLight->setObjectName(QStringLiteral("btnAddLight"));
        btnAddLight->setGeometry(QRect(320, 50, 31, 31));
        btnDeleteLight = new QPushButton(Lights);
        btnDeleteLight->setObjectName(QStringLiteral("btnDeleteLight"));
        btnDeleteLight->setGeometry(QRect(320, 200, 31, 31));
        groupBox_2 = new QGroupBox(Lights);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 240, 341, 61));
        posX = new QLineEdit(groupBox_2);
        posX->setObjectName(QStringLiteral("posX"));
        posX->setGeometry(QRect(40, 30, 61, 21));
        posY = new QLineEdit(groupBox_2);
        posY->setObjectName(QStringLiteral("posY"));
        posY->setGeometry(QRect(140, 30, 61, 21));
        posZ = new QLineEdit(groupBox_2);
        posZ->setObjectName(QStringLiteral("posZ"));
        posZ->setGeometry(QRect(250, 30, 61, 21));
        labX = new QLabel(groupBox_2);
        labX->setObjectName(QStringLiteral("labX"));
        labX->setGeometry(QRect(20, 30, 21, 16));
        labY = new QLabel(groupBox_2);
        labY->setObjectName(QStringLiteral("labY"));
        labY->setGeometry(QRect(120, 30, 21, 16));
        labZ = new QLabel(groupBox_2);
        labZ->setObjectName(QStringLiteral("labZ"));
        labZ->setGeometry(QRect(230, 30, 21, 16));
        label = new QLabel(Lights);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 370, 62, 16));
        label_2 = new QLabel(Lights);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 410, 62, 16));
        label_3 = new QLabel(Lights);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(20, 450, 62, 16));
        btnOpenDiffColor = new QPushButton(Lights);
        btnOpenDiffColor->setObjectName(QStringLiteral("btnOpenDiffColor"));
        btnOpenDiffColor->setGeometry(QRect(100, 360, 111, 32));
        btnOpenSpecColor = new QPushButton(Lights);
        btnOpenSpecColor->setObjectName(QStringLiteral("btnOpenSpecColor"));
        btnOpenSpecColor->setGeometry(QRect(100, 400, 111, 32));
        btnOpenAmbColor = new QPushButton(Lights);
        btnOpenAmbColor->setObjectName(QStringLiteral("btnOpenAmbColor"));
        btnOpenAmbColor->setGeometry(QRect(100, 440, 111, 32));
   //     label_4 = new QLabel(Lights);
   //     label_4->setObjectName(QStringLiteral("label_4"));
   //     label_4->setGeometry(QRect(20, 500, 62, 16));
   //     comboBox = new QComboBox(Lights);
   //     comboBox->setObjectName(QStringLiteral("comboBox"));
   //     comboBox->setGeometry(QRect(240, 490, 111, 26));
        label_5 = new QLabel(Lights);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(240, 320, 111, 20));
        line = new QFrame(Lights);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(10, 470, 341, 20));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        label_8 = new QLabel(Lights);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(20, 320, 62, 16));
        label_9 = new QLabel(Lights);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(110, 320, 62, 16));
        doubleSpinBox = new QDoubleSpinBox(Lights);
        doubleSpinBox->setObjectName(QStringLiteral("doubleSpinBox"));
        doubleSpinBox->setGeometry(QRect(240, 360, 81, 24));
        doubleSpinBox->setMaximum(100);
        doubleSpinBox_2 = new QDoubleSpinBox(Lights);
        doubleSpinBox_2->setObjectName(QStringLiteral("doubleSpinBox_2"));
        doubleSpinBox_2->setGeometry(QRect(240, 400, 81, 24));
        doubleSpinBox_2->setMaximum(100);
        doubleSpinBox_3 = new QDoubleSpinBox(Lights);
        doubleSpinBox_3->setObjectName(QStringLiteral("doubleSpinBox_3"));
        doubleSpinBox_3->setGeometry(QRect(240, 440, 81, 24));
        doubleSpinBox_3->setMaximum(100);
        pushButton = new QPushButton(Lights);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(10, 490, 91, 32));
  //      pushButton_2 = new QPushButton(Lights);
  //      pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
  //      pushButton_2->setGeometry(QRect(240, 540, 91, 32));
  //      progressBar = new QProgressBar(Lights);
  //      progressBar->setObjectName(QStringLiteral("progressBar"));
  //      progressBar->setGeometry(QRect(20, 580, 321, 23));
  //      progressBar->setValue(24);
        
        verticalLayout_5->addWidget(Lights);
        
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 384, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        
        retranslateUi(MainWindow);
        
        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi
    
    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        Lights->setTitle(QApplication::translate("MainWindow", "Lights", 0));
        btnAddLight->setText(QApplication::translate("MainWindow", "+", 0));
        btnDeleteLight->setText(QApplication::translate("MainWindow", "-", 0));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Position", 0));
        labX->setText(QApplication::translate("MainWindow", "x:", 0));
        labY->setText(QApplication::translate("MainWindow", "y:", 0));
        labZ->setText(QApplication::translate("MainWindow", "z:", 0));
        label->setText(QApplication::translate("MainWindow", "Diffuse", 0));
        label_2->setText(QApplication::translate("MainWindow", "Specular", 0));
        label_3->setText(QApplication::translate("MainWindow", "Ambient", 0));
        btnOpenDiffColor->setText(QApplication::translate("MainWindow", "Choose", 0));
        btnOpenSpecColor->setText(QApplication::translate("MainWindow", "Choose", 0));
        btnOpenAmbColor->setText(QApplication::translate("MainWindow", "Choose", 0));
   //     label_4->setText(QApplication::translate("MainWindow", "Type", 0));
   //     comboBox->clear();
   //     comboBox->insertItems(0, QStringList()
   //                           << QApplication::translate("MainWindow", "Omni", 0)
   //                           << QApplication::translate("MainWindow", "Spot", 0)
   //                           );
        label_5->setText(QApplication::translate("MainWindow", "Alpha channel (%)", 0));
        label_8->setText(QApplication::translate("MainWindow", "Channel", 0));
        label_9->setText(QApplication::translate("MainWindow", "Color", 0));
        pushButton->setText(QApplication::translate("MainWindow", "Ok!", 0));
  //      pushButton_2->setText(QApplication::translate("MainWindow", "Render", 0));
    } // retranslateUi
    
};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

